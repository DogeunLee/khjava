package edu.kh.array.ex;

public class ArrayExampleRun {
	public static void main(String[] args) {
		
		ArrayExample arrayEx = new ArrayExample();
		
//		arrayEx.ex1();
//		arrayEx.ex2();
//		arrayEx.ex3();
//		arrayEx.ex4();
//		arrayEx.ex5();
//		arrayEx.ex6();
//		arrayEx.ex7();
//		arrayEx.ex8();
//		arrayEx.createLottoNumber();
//		arrayEx.ex9();
//		arrayEx.ex10();
//		arrayEx.ex11();
		
		
		ArrayExample2 arrayEx2 = new ArrayExample2();
		
//		arrayEx2.ex1();
//		arrayEx2.ex2();
//		arrayEx2.ex3();
		arrayEx2.ex4();
		
		
	}
	
	
	
	
}

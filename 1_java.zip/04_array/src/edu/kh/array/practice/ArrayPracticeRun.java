package edu.kh.array.practice;

public class ArrayPracticeRun {

	public static void main(String[] args) {
		
		ArrayPractice ap = new ArrayPractice();
		
//		ap.practice1();
//		ap.practice2();
//		ap.practice3();
//		ap.practice4();
//		ap.practice5();
//		ap.practice6();
//		ap.practice7();
//		ap.practice8();
//		ap.practice9();
//		ap.practice10();
		ap.practice11();
//		ap.practice12();
//		ap.practice13();
//		ap.practice14();
//		ap.practice15();
//		ap.practice16();
//		ap.practice17();
//		ap.practice18();
//		ap.practice19();
//		ap.practice20();
//		ap.practice21();
//		ap.practice22();
//		ap.practice23();
//		ap.practice24();
	}
}

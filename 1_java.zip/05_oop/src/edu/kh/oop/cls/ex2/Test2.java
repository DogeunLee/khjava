package edu.kh.oop.cls.ex2;

public class Test2 {
	// 다른 패키지에 존재하는 클래스
	
	public void ex() {
		Test100 t100 = new Test100();
		
		System.out.println(t100.b);
	}
}

class Test3{}

class Test4{}






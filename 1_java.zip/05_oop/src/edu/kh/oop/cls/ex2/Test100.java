package edu.kh.oop.cls.ex2;

class Test100 {
	public int b;
}

package edu.kh.oop.cls.ex1;

class Test100 {
	public int a;
}

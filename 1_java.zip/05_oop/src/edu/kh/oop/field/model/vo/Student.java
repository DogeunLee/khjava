package edu.kh.oop.field.model.vo;

// 클래스 : 객체의 속성과 기능을 정의한 문서(설계도)
public class Student {

	// 필드 : 객체의 속성
	public String name;
	public static String schoolName = "KH 고등학교"; 
	
	// 메서드 : 객체의 기능
	public void study() {
		System.out.println("공부합니다.");
	}
	
}



package edu.kh.control.branch;

public class BranchRun {
	public static void main(String[] args) {
		
		BranchExample branchEx = new BranchExample();
		
//		branchEx.ex1();
//		branchEx.ex2();
//		branchEx.ex3();
//		branchEx.ex4();
//		branchEx.ex5();
//		branchEx.upDownGame();
		branchEx.rpsGame();
	}
}

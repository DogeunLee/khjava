package edu.kh.control.condition.practice;

public class ConditionPracticeRun {
	
	public static void main(String[] args) {
		
		ConditionPractice cp = new ConditionPractice();
		
//		cp.practice4();
		cp.practice5();
	}
	
}

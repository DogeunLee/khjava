package edu.kh.control.condition;

// 코드를 실행시키는 부분(시키는 사람)
public class ConditionRun {

	public static void main(String[] args) {
		
		ConditionExample ex = new ConditionExample();
		
		// 커서놓고 -> ctrl + /  == 한 줄 주석
//		ex.test1();
//		ex.test2();
		
//		ex.ex1();
//		ex.ex2();
//		ex.ex3();
//		ex.ex4();
//		ex.ex5();
	
		
		SwitchExample switchEx = new SwitchExample();
		
//		switchEx.ex1();
//		switchEx.ex2();
//		switchEx.ex3();
//		switchEx.ex4();
		switchEx.ex4v2();
//		switchEx.ex5();
		
		
		
	}
}

package edu.kh.control.loop.practice;

public class LoopPracticeRun {
	
	public static void main(String[] args) {
		
		LoopPractice lp = new LoopPractice();

//		lp.practice1();
//		lp.practice2();
//		lp.practice3();
//		lp.practice4();
//		lp.practice5();
//		lp.practice6();
//		lp.practice7();
//		lp.practice8();
//		lp.practice9();
//		lp.practice10();
//		lp.practice11();
//		lp.practice12();
		lp.practice13();
	}
	
}

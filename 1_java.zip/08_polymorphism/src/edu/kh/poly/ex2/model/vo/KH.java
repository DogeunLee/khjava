package edu.kh.poly.ex2.model.vo;

public interface KH { // 인터페이스

	// 필드(public static final)
	/*public static final*/ String ADDRESS = "서울시 중구 남대문로 120";
	
	// 메서드(public abstract)
	/*public abstract*/ void lesson(); // 수업
	
}

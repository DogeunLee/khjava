package edu.kh.poly.ex2.model.vo;

public class HGD implements KH{ // 홍길동 (B반 학생)
	@Override
	public void lesson() {
		System.out.println("B강의장에서 보안 엔지니어 과정 수강");
	} 
}

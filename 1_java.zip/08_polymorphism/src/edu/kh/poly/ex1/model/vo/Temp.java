package edu.kh.poly.ex1.model.vo;

// toString() 오버라이딩 확인
public class Temp {
	public static void main(String[] args) {
		
		Car c = new Car(4, 4, "경유");
		
		System.out.println( c.toString()  );
		
	}
}

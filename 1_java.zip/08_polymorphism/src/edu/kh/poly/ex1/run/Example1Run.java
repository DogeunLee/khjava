package edu.kh.poly.ex1.run;

import edu.kh.poly.ex1.model.service.Example1;

public class Example1Run {
	public static void main(String[] args) {
		
		Example1 exam1 = new Example1();
		
		exam1.ex1();
//		exam1.ex2();
//		exam1.ex3();
//		exam1.ex4();
		
		
		
		
	}
}

package edu.kh.exception.model.vo;

import java.io.IOException;

public abstract class Parent {

	public abstract void method() throws IOException;
}

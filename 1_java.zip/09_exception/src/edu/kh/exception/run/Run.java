package edu.kh.exception.run;

import edu.kh.exception.model.service.Example;

public class Run {
	public static void main(String[] args) {
		Example exam = new Example();
		
//		exam.ex1();
//		exam.ex2();
//		exam.ex3();
		exam.ex4();
		
	}
}

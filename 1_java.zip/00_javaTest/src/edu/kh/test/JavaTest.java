package edu.kh.test;

// 한 줄 주석 : (컴파일러(번역기)가 해석하지 않는 부분

/* 범위
   주석 */
 
//class : 자바 코드가 작성되는 영역
public class JavaTest {

	// main 메서드 : 자바 애플리케이션(프로그램)을 실행하기 위해서 반드시 필요한 구문
	public static void main(String[] args) {


		//System.out.println("점심 맛있게 드셨나요?.");
		System.out.println("println()은 한 줄 출력입니다.");
		System.out.println( 100 + 200 + 300 + 400 );
	}

	
}
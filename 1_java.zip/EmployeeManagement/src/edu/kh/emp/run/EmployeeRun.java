package edu.kh.emp.run;

import edu.kh.emp.view.EmployeeViewImpl;

public class EmployeeRun {
	public static void main(String[] args) {
		new EmployeeViewImpl().displayMenu();
	}
}
